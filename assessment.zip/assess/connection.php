<?php
 
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "test";

$conn =  new mysqli($servername, $username, $password, $dbname);

?>